# arnica filter

This is an software application in construction.

Dies ist eine Anwendungssoftware zum Monitoring von Arnika Blumen durch die Auswertung von Luftbildern von Drohnen

todos:

- close option in menu
- Anmerkungen von Weinacker einarbeiten (v.A. Parameter aus Bilddaten vorschlagen)
- Modulvorraussetzungen und Fehlermeldungen programmieren

- Softwaretests -> Debugging

- Kommentierung 
- PEP 8 -> pylind