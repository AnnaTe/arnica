# arnica filter

This is an software application  ... in construction.

Dies ist eine Anwendungssoftware zum Monitoring von Arnika Blumen durch die Auswertung von Luftbildern von Drohnen

todos:

- close option in menu
- Anmerkungen von Weinacker einarbeiten (v.A. Parameter aus Bilddaten vorschlagen)
- Modulvorraussetzungen und Fehlermeldungen programmieren

- Softwaretests -> Debugging

Default size aus der Flughöhe angeben und Auflösung der Kamera
-> Blobsize in px aus Auflösung berechnen

helligkeit des bildes erkennen und daran den gelbwert anpassen?? -> histogramm?
warum werden auf den testbildern die dunklen blumen nicht erkannt/die blumen im schatten nicht erkannt

Anzeige: Bild 5 von 100

Maybe/nice to have:
- support of other imageformats .png, etc?
- help html

- Kommentierung 
- PEP 8 -> pylind